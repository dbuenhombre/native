#!/bin/bash

echo "Use the iOS/Android app to load the wg0.conf file and stop Wireguard"
