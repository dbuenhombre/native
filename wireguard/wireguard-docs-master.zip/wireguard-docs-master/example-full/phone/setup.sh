#!/bin/bash

# install wireguard on iOS/Android
echo "Use the iOS App Store / Google Play Store to install WireGuard on your mobile device"
