#!/bin/bash

# install wireguard on Ubuntu
#add-apt-repository ppa:wireguard/wireguard
#apt update
#apt install wireguard

# install wireguard on macOS
brew install wireguard-tools
