#!/bin/bash

# install wireguard
add-apt-repository ppa:wireguard/wireguard
apt update
apt install wireguard
