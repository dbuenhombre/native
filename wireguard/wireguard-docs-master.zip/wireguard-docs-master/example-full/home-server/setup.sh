#!/bin/bash

# install wireguard on FreeBSD
pkg install wireguard

# install wireguard on Ubuntu
#add-apt-repository ppa:wireguard/wireguard
#apt update
#apt install wireguard
